#!/bin/bash

cd /tmp
"$1" /Volumes/OS\ X\ Install\ ESD/Packages/Essentials.pkg 419 | cpio -idmu '*kernel'
cp -Ra System "$2"